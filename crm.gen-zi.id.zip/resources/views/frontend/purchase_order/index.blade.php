<x-app-layout>
    <div class="container-fluid">
        <div class="row">

            <div class="col-sm-12 col-lg-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title">Kelola Pembelian Barang</h4>

                        </div>
                        <button onclick="addData()" style="float: right;" type="button"
                            class="btn btn-sm btn-success rounded-pill mt-2">+ Tambah
                            Pembelian Barang</button>

                    </div>
                    <div class="card-body">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-3 p-2">
                                        <div class="form-group">
                                            <label>Tanggal</label>
                                            <input type="date" id="filter_date" class="form-control sm-input">
                                        </div>
                                    </div>
                                    <div class="col-3 p-2">
                                        <div class="form-group">
                                            <label>Vendor</label>
                                            <select id="filter_vendor" class="form-control sm-input">
                                                <option value="" selected>Semua Vendor</option>
                                                @foreach($vendors as $vendor)
                                                    <option value="{{ $vendor->id }}">{{ $vendor->vendor_name }}</option>
                                                @endforeach
                                               
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-3 p-2">
                                        <div class="form-group">
                                            <label>Status</label>
                                            <select id="filter_status" class="form-control sm-input">
                                                <option value="" selected>Semua</option>
                                                <option value="1">Pengajuan</option>
                                                <option value="2">Tunda</option>
                                                <option value="3">Disetujui</option>
                                                <option value="4">Revisi</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-1">
                                        <button id="btn-filter-data" style="margin-top: 38px;" type="button"
                                            class="btn btn-info">Filter</button>
                                    </div>
                                    <div class="col-1">
                                        <button id="btn-refresh-data" style="margin-top: 38px;" type="button"
                                            class="btn btn-success">Refresh</button>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered nowrap" id="table-list">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Nomor PO</th>
                                        <th scope="col">Vendor</th>
                                        <th scope="col">Tanggal Pembelian</th>
                                        <th scope="col">PIC</th>
                                        <th scope="col">Gudang</th>
                                        <th scope="col">Mill</th>
                                        <th scope="col">Status</th>
                                        <th style="width: 200px;" scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="modal-add" class="modal fade" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <form type="POST" id="form-purchase-order">
                    {{ csrf_field() }} {{ method_field('POST') }}
                    <input type="hidden" id="id" name="id">
                    <div class="modal-header">
                        <h5 class="modal-title"></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <div class="row">
                            <div class="col-3">
                                <div class="form-group">
                                    <label>Permintaan Barang (PR)</label>
                                    <select id="purchase_request_id" name="purchase_request_id" class="form-control select2 sm-input">
                                        <option value="" selected disabled>Pilih Nomor Permintaan Barang
                                        </option>
                                        
                                    </select>
                                    <input type="hidden" id="purchase_request_number" name="purchase_request_number">
                                </div>

                            </div>
                            <div class="col-1" style="margin-left: -27px;">
                                <button id="btn-proses-data" style="margin-top: 30px;" type="button"
                                    class="btn btn-info">Proses</button>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-3">
                                <div class="form-group">
                                    <label class="bintang">Vendor</label>
                                    <select class="form-control sm-input" id="vendor_id" name="vendor_id">
                                        <option value="" selected disabled>Pilih Vendor</option>
                                        @foreach ($vendors as $vendor)
                                            <option value="{{ $vendor->id }}">{{ $vendor->vendor_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="col-3">
                                <div class="form-group">
                                    <label class="bintang">Tujuan</label>
                                    <select class="form-control sm-input" id="vendor_address_id" name="vendor_address_id">
                                        <option value="" selected disabled>Pilih Tujuan</option>
                                        @foreach($whs as $w)
                                            <option value="{{ $w->id }}">{{ $w->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="col-2">
                                <div class="form-group">
                                    <label class="bintang">Nomor PO</label>
                                    <input class="form-control sm-input" type="text" id="purchase_order_number"
                                        name="purchase_order_number" readonly>
                                </div>
                            </div>

                            <div class="col-2">
                                <div class="form-group">
                                    <label class="bintang">Tanggal Pesan</label>
                                    <input value="{{ date('Y-m-d') }}" class="form-control sm-input" type="date"
                                        id="purchase_order_date" name="purchase_order_date">
                                </div>
                            </div>

                            <div class="col-2">
                                <div class="form-group">
                                    <label class="bintang">Mill</label>
                                    <select class="form-control sm-input" id="mill"
                                        name="mill">
                                        <option value="" selected disabled>Pilih Mill</option>
                                        @foreach($mls as $m)
                                            <option value="{{ $m->mills_name }}">{{ $m->mills_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                        </div>



                        <div class="row">
                            <div class="col-3">
                                <div style="font-size:11px;line-height:16px;position:relative;top:-6px;" class="note-list" id="vendor-note"></div>
                            </div>
                            <div class="col-3">
                                <div style="font-size:11px;line-height:16px;position:relative;top:-6px;" class="note-list" id="vendor-address-note"></div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Kategori</label>
                                    <input readonly type="text" class="form-control sm-input" id="product_category"
                                        name="product_category">

                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label class="bintang">Metode Pembayaran</label>
                                    <select class="form-control sm-input" id="payment_method" name="payment_method">
                                        <option value="" selected disabled>Pilih Metode Pembayaran</option>
                                        @foreach($payment_methods as $payment)
                                            <option value="{{ $payment->id }}">{{ $payment->code }} ( {{ $payment->description }} )</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="col-2">
                                <div class="form-group">
                                    <label class="bintang">Metode Pengiriman</label>
                                    <select class="form-control sm-input" id="delivery_method" name="delivery_method">
                                        <option value="" selected disabled>Pilih Metode Pengiriman</option>
                                        @foreach($delivery_methods as $delivery)
                                            <option value="{{ $delivery->id }}">{{ $delivery->name }} ( {{ $delivery->description }} )</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6"></div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label class="bintang">Deskripsi</label>
                                    <textarea class="form-control" id="description" name="description"></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="card">

                                    <div class="card-body">
                                        <div class="card-title" style="background: beige;padding:10px;">
                                            Detail Produk
                                        </div>
                                        <!-- container untuk menampung semua row -->
                                        <div id="product_items">
                                            <center><span style="font-size: 12px;">Belum ada daftar produk</span></center>

                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-8" style="padding-left:0px; padding-right:0px;"></div>
                                            <div class="col-2"
                                                style="font-size:13px;margin-left:-10px;padding-left:0px; padding-right:0px; text-align:left; display:flex; align-items:center; justify-content:flex-start;">
                                                Subtotal&nbsp;&nbsp;&nbsp;&nbsp;
                                            </div>

                                            <div class="col-2" style="padding-left:2px; padding-right:0px;">
                                                <input type="text" readonly class="form-control sm-input" id="subtotal"
                                                    name="subtotal">
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-8" style="padding-left:2px; padding-right:2px;"></div>
                                            <div class="col-2"
                                                style="font-size:13px;margin-left:-10px;padding-left:0px; padding-right:0px; text-align:left; display:flex; align-items:center; justify-content:flex-start;">
                                                Pajak&nbsp;&nbsp;&nbsp;&nbsp;
                                            </div>

                                            <div class="col-2" style="padding-left:2px; padding-right:0px;">
                                                <input type="text" readonly class="form-control sm-input" id="total_tax"
                                                    name="total_tax">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-8" style="padding-left:2px; padding-right:2px;"></div>
                                            <div class="col-2"
                                                style="font-size:13px;margin-left:-10px;padding-left:0px; padding-right:0px; text-align:left; display:flex; align-items:center; justify-content:flex-start;">
                                                Jumlah Total&nbsp;&nbsp;&nbsp;&nbsp;
                                            </div>

                                            <div class="col-2" style="padding-left:2px; padding-right:0px;">
                                                <input type="text" readonly class="form-control sm-input" id="total_price"
                                                    name="total_price">
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>


                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
                        <button id="btn-save-data" type="submit" class="btn btn-success btn-sm">Save</button>
                        
                    </div>
                </form>
            </div>
        </div>
    </div>


    <div id="modal-view" class="modal fade" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <input type="hidden" id="purchase_id_show">
                <div class="modal-body" id="modal-view-content"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Batal</button>
                    <button style="display: none;" id="btn-reject-data" type="button" class="btn btn-danger btn-sm"><i
                            class="fa fa-close"></i> Revisi</button>
                    <button style="display: none;" id="btn-approve-data" type="button" class="btn btn-success btn-sm"><i
                            class="fa fa-check"></i>Setujui</button>
                    <button style="display: none;" id="btn-propose-data" style="display: none"; type="button" class="btn btn-info btn-sm"><i class="fa fa-arrow-right"></i>Ajukan</button>


                </div>
            </div>
        </div>
    </div>


    <div id="modal-reason" class="modal fade" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body" id="modal-reason-content"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Tutup</button>

                </div>
            </div>
        </div>
    </div>

</x-app-layout>



@include('frontend.purchase_order.script')
