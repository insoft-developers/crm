<x-app-layout>
<div class="container">
         <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-12">
               <div class="card card-block card-stretch card-height blog">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title">Flat Button</h4>
                     </div>
                  <div class="header-action">
                           <i  type="button" data-toggle="collapse" data-target="#button-group-1" aria-expanded="false" aria-controls="alert-1">
                              <svg width="20" height="20" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                              </svg>
                           </i>
                        </div>
                  </div>
                  <div class="card-body">
                     <div class="collapse" id="button-group-1">
                           <div class="card"><kbd class="bg-dark"><pre id="flat-button" class="text-white"><code>
&#x3C;div class=&#x22;btn-group btn-group-toggle btn-group-flat&#x22;&#x3E; 
   &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Left&#x3C;/a&#x3E;
   &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Middle&#x3C;/a&#x3E;
   &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Right&#x3C;/a&#x3E;
&#x3C;/div&#x3E;
</code></pre></kbd></div>
                        </div>
                     <ul class="list-inline p-0 m-0 text-center">
                        <li class="mb-2">
                           <div class="btn-group btn-group-toggle btn-group-flat"> <a class="button btn button-icon bg-primary" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon bg-primary" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon bg-primary" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                        <li class="mb-2">
                           <div class="btn-group btn-group-toggle btn-group-flat"> <a class="button btn button-icon bg-success" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon bg-success" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon bg-success" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                        <li>
                           <div class="btn-group btn-group-toggle btn-group-flat"> <a class="button btn button-icon bg-warning" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon bg-warning" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon bg-warning" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
               <div class="card card-block card-stretch card-height blog">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title">Edges Button</h4>
                     </div>
                  <div class="header-action">
                           <i  type="button" data-toggle="collapse" data-target="#button-group-2" aria-expanded="false" aria-controls="alert-1">
                              <svg width="20" height="20" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                              </svg>
                           </i>
                        </div>
                  </div>
                  <div class="card-body">
                     <div class="collapse" id="button-group-2">
                           <div class="card"><kbd class="bg-dark"><pre id="edge-button" class="text-white"><code>
&#x3C;div class=&#x22;btn-group btn-group-toggle btn-group-edges&#x22;&#x3E; 
   &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Left&#x3C;/a&#x3E;
   &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Middle&#x3C;/a&#x3E;
   &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Right&#x3C;/a&#x3E;
&#x3C;/div&#x3E;
</code></pre></kbd></div>
                        </div>
                     <ul class="list-inline p-0 m-0 text-center">
                        <li class="mb-2">
                           <div class="btn-group btn-group-toggle btn-group-edges"> <a class="button btn button-icon bg-primary" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon bg-primary" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon bg-primary" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                        <li class="mb-2">
                           <div class="btn-group btn-group-toggle btn-group-edges"> <a class="button btn button-icon bg-success" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon bg-success" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon bg-success" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                        <li>
                           <div class="btn-group btn-group-toggle btn-group-edges"> <a class="button btn button-icon bg-warning" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon bg-warning" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon bg-warning" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
               <div class="card card-block card-stretch card-height blog">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title">Basic Buttons</h4>
                     </div>
                  <div class="header-action">
                           <i  type="button" data-toggle="collapse" data-target="#button-group-3" aria-expanded="false" aria-controls="alert-1">
                              <svg width="20" height="20" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                              </svg>
                           </i>
                        </div>
                  </div>
                  <div class="card-body">
                     <div class="collapse" id="button-group-3">
                           <div class="card"><kbd class="bg-dark"><pre id="basic-button" class="text-white"><code>
&#x3C;div class=&#x22;btn-group btn-group-toggle&#x22;&#x3E; 
   &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Left&#x3C;/a&#x3E;
   &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Middle&#x3C;/a&#x3E;
   &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Right&#x3C;/a&#x3E;
&#x3C;/div&#x3E;
</code></pre></kbd></div>
                        </div>
                     <ul class="list-inline p-0 m-0 text-center">
                        <li class="mb-2">
                           <div class="btn-group btn-group-toggle"> <a class="button btn button-icon bg-primary" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon bg-primary" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon bg-primary" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                        <li class="mb-2">
                           <div class="btn-group btn-group-toggle"> <a class="button btn button-icon bg-success" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon bg-success" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon bg-success" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                        <li>
                           <div class="btn-group btn-group-toggle"> <a class="button btn button-icon bg-warning" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon bg-warning" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon bg-warning" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
               <div class="card card-block card-stretch card-height blog">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title">Outline Middle Buttons</h4>
                     </div>
                  <div class="header-action">
                           <i  type="button" data-toggle="collapse" data-target="#button-group-4" aria-expanded="false" aria-controls="alert-1">
                              <svg width="20" height="20" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                              </svg>
                           </i>
                        </div>
                  </div>
                  <div class="card-body">
                     <div class="collapse" id="button-group-4">
                           <div class="card"><kbd class="bg-dark"><pre id="outline-middle-button" class="text-white"><code>
&#x3C;div class=&#x22;btn-group btn-group-toggle&#x22;&#x3E; 
   &#x3C;a class=&#x22;button btn button-icon btn-outline-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Left&#x3C;/a&#x3E;
   &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Middle&#x3C;/a&#x3E;
   &#x3C;a class=&#x22;button btn button-icon btn-outline-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Right&#x3C;/a&#x3E;
&#x3C;/div&#x3E;
</code></pre></kbd></div>
                        </div>
                     <ul class="list-inline p-0 m-0 text-center">
                        <li class="mb-2">
                           <div class="btn-group btn-group-toggle"> <a class="button btn button-icon btn-outline-primary" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon bg-primary" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon btn-outline-primary" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                        <li class="mb-2">
                           <div class="btn-group btn-group-toggle"> <a class="button btn button-icon btn-outline-success" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon bg-success" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon btn-outline-success" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                        <li>
                           <div class="btn-group btn-group-toggle"> <a class="button btn button-icon btn-outline-warning" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon bg-warning" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon btn-outline-warning" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
               <div class="card card-block card-stretch card-height blog">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title">Outline Side Buttons</h4>
                     </div>
                  <div class="header-action">
                           <i  type="button" data-toggle="collapse" data-target="#button-group-5" aria-expanded="false" aria-controls="alert-1">
                              <svg width="20" height="20" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                              </svg>
                           </i>
                        </div>
                  </div>
                  <div class="card-body">
                     <div class="collapse" id="button-group-5">
                           <div class="card"><kbd class="bg-dark"><pre id="outline-side-button" class="text-white"><code>
&#x3C;div class=&#x22;btn-group btn-group-toggle&#x22;&#x3E; 
   &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Left&#x3C;/a&#x3E;
   &#x3C;a class=&#x22;button btn button-icon btn-outline-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Middle&#x3C;/a&#x3E;
   &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Right&#x3C;/a&#x3E;
&#x3C;/div&#x3E;
</code></pre></kbd></div>
                        </div>
                     <ul class="list-inline p-0 m-0 text-center">
                        <li class="mb-2">
                           <div class="btn-group btn-group-toggle"> <a class="button btn button-icon bg-primary" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon btn-outline-primary" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon bg-primary" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                        <li class="mb-2">
                           <div class="btn-group btn-group-toggle"> <a class="button btn button-icon bg-success" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon btn-outline-success" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon bg-success" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                        <li>
                           <div class="btn-group btn-group-toggle"> <a class="button btn button-icon bg-warning" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon btn-outline-warning" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon bg-warning" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
               <div class="card card-block card-stretch card-height blog">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title">Outline Buttons</h4>
                     </div>
                  <div class="header-action">
                           <i  type="button" data-toggle="collapse" data-target="#button-group-6" aria-expanded="false" aria-controls="alert-1">
                              <svg width="20" height="20" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                              </svg>
                           </i>
                        </div>
                  </div>
                  <div class="card-body">
                     <div class="collapse" id="button-group-6">
                           <div class="card"><kbd class="bg-dark"><pre id="outline-button" class="text-white"><code>
&#x3C;div class=&#x22;btn-group btn-group-toggle&#x22;&#x3E; 
   &#x3C;a class=&#x22;button btn button-icon btn-outline-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Left&#x3C;/a&#x3E;
   &#x3C;a class=&#x22;button btn button-icon btn-outline-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Middle&#x3C;/a&#x3E;
   &#x3C;a class=&#x22;button btn button-icon btn-outline-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Right&#x3C;/a&#x3E;
&#x3C;/div&#x3E;
</code></pre></kbd></div>
                        </div>
                     <ul class="list-inline p-0 m-0 text-center">
                        <li class="mb-2">
                           <div class="btn-group btn-group-toggle"> <a class="button btn button-icon btn-outline-primary" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon btn-outline-primary" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon btn-outline-primary" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                        <li class="mb-2">
                           <div class="btn-group btn-group-toggle"> <a class="button btn button-icon btn-outline-success" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon btn-outline-success" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon btn-outline-success" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                        <li>
                           <div class="btn-group btn-group-toggle"> <a class="button btn button-icon btn-outline-warning" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon btn-outline-warning" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon btn-outline-warning" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12">
               <div class="card card-block card-stretch card-height blog">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title">Toolbar Buttons</h4>
                     </div>
                  <div class="header-action">
                           <i  type="button" data-toggle="collapse" data-target="#button-group-7" aria-expanded="false" aria-controls="alert-1">
                              <svg width="20" height="20" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                              </svg>
                           </i>
                        </div>
                  </div>
                  <div class="card-body">
                     <div class="collapse" id="button-group-7">
                           <div class="card"><kbd class="bg-dark"><pre id="toolbar-button" class="text-white"><code>
&#x3C;li class=&#x22;d-flex align-items-center justify-content-center mb-2&#x22;&#x3E;
   &#x3C;div class=&#x22;btn-group btn-group-toggle btn-group-edges mr-2 btn-group1&#x22;&#x3E; 
      &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;1&#x3C;/a&#x3E;
      &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;2&#x3C;/a&#x3E;
      &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;3&#x3C;/a&#x3E;
   &#x3C;/div&#x3E;
   &#x3C;div class=&#x22;btn-group btn-group-toggle btn-group-edges mr-2 btn-group2&#x22;&#x3E; &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;4&#x3C;/a&#x3E;
      &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;5&#x3C;/a&#x3E;
   &#x3C;/div&#x3E;
   &#x3C;div class=&#x22;btn-group btn-group-toggle btn-group3&#x22;&#x3E; 
      &#x3C;a class=&#x22;button btn button-icon bg-primary rounded&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;6&#x3C;/a&#x3E;
   &#x3C;/div&#x3E;
&#x3C;/li&#x3E;
</code></pre></kbd></div>
                        </div>
                     <ul class="list-inline p-0 m-0 text-center">
                        <li class="d-flex align-items-center justify-content-center mb-2">
                           <div class="btn-group btn-group-toggle btn-group-edges mr-2 btn-group1"> <a class="button btn button-icon bg-primary" target="_blank" href="#">1</a>
                              <a class="button btn button-icon bg-primary" target="_blank" href="#">2</a>
                              <a class="button btn button-icon bg-primary" target="_blank" href="#">3</a>
                           </div>
                           <div class="btn-group btn-group-toggle btn-group-edges mr-2 btn-group2"> <a class="button btn button-icon bg-primary" target="_blank" href="#">4</a>
                              <a class="button btn button-icon bg-primary" target="_blank" href="#">5</a>
                           </div>
                           <div class="btn-group btn-group-toggle btn-group3"> <a class="button btn button-icon bg-primary rounded" target="_blank" href="#">6</a>
                           </div>
                        </li>
                        <li class="d-flex align-items-center justify-content-center mb-2">
                           <div class="btn-group btn-group-toggle btn-group-edges mr-2 btn-group1"> <a class="button btn button-icon bg-success" target="_blank" href="#">1</a>
                              <a class="button btn button-icon bg-success" target="_blank" href="#">2</a>
                              <a class="button btn button-icon bg-success" target="_blank" href="#">3</a>
                           </div>
                           <div class="btn-group btn-group-toggle btn-group-edges mr-2 btn-group2"> <a class="button btn button-icon bg-success" target="_blank" href="#">4</a>
                              <a class="button btn button-icon bg-success" target="_blank" href="#">5</a>
                           </div>
                           <div class="btn-group btn-group-toggle btn-group3"> <a class="button btn button-icon bg-success rounded" target="_blank" href="#">6</a>
                           </div>
                        </li>
                        <li class="d-flex align-items-center justify-content-center">
                           <div class="btn-group btn-group-toggle btn-group-edges mr-2 btn-group1"> <a class="button btn button-icon bg-warning" target="_blank" href="#">1</a>
                              <a class="button btn button-icon bg-warning" target="_blank" href="#">2</a>
                              <a class="button btn button-icon bg-warning" target="_blank" href="#">3</a>
                           </div>
                           <div class="btn-group btn-group-toggle btn-group-edges mr-2 btn-group2"> <a class="button btn button-icon bg-warning" target="_blank" href="#">4</a>
                              <a class="button btn button-icon bg-warning" target="_blank" href="#">5</a>
                           </div>
                           <div class="btn-group btn-group-toggle btn-group3"> <a class="button btn button-icon bg-warning rounded" target="_blank" href="#">6</a>
                           </div>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12">
               <div class="card card-block card-stretch card-height blog">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title">Basic Buttons</h4>
                     </div>
                  <div class="header-action">
                           <i  type="button" data-toggle="collapse" data-target="#button-group-8" aria-expanded="false" aria-controls="alert-1">
                              <svg width="20" height="20" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                              </svg>
                           </i>
                        </div>
                  </div>
                  <div class="card-body">
                     <div class="collapse" id="button-group-8">
                           <div class="card"><kbd class="bg-dark"><pre id="basic-button" class="text-white"><code>
&#x3C;div class=&#x22;btn-group btn-group-toggle btn-group-sm  btn-group-edges&#x22;&#x3E; 
   &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Left&#x3C;/a&#x3E;
   &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Middle&#x3C;/a&#x3E;
   &#x3C;a class=&#x22;button btn button-icon bg-primary&#x22; target=&#x22;_blank&#x22; href=&#x22;#&#x22;&#x3E;Right&#x3C;/a&#x3E;
&#x3C;/div&#x3E;
</code></pre></kbd></div>
                        </div>
                     <ul class="list-inline p-0 m-0 text-center">
                        <li class="mb-2">
                           <div class="btn-group btn-group-toggle btn-group-sm  btn-group-edges"> <a class="button btn button-icon bg-primary" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon bg-primary" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon bg-primary" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                        <li class="mb-2">
                           <div class="btn-group btn-group-toggle  btn-group-edges"> <a class="button btn button-icon bg-success" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon bg-success" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon bg-success" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                        <li>
                           <div class="btn-group btn-group-toggle btn-group-lg  btn-group-edges"> <a class="button btn button-icon bg-warning" target="_blank" href="#">Left</a>
                              <a class="button btn button-icon bg-warning" target="_blank" href="#">Middle</a>
                              <a class="button btn button-icon bg-warning" target="_blank" href="#">Right</a>
                           </div>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
</x-app-layout>
